<?php include('includes/header.php');?>
<div class="row-fluid">
    <div>
        <select id="selected_plan">
        <?php 
            $q = 'SELECT * FROM payment_plans WHERE is_active = 1';
            $r = mysqli_query($mysqli, $q);
            if ($r && mysqli_num_rows($r) > 0)
            {
                while($row = mysqli_fetch_array($r))
                {
                    $id = $row['id'];
                    $name = $row['name'];
                    $amount = $row['amount'];
                    
                    echo '
                        <option value="' . $id . '">
                            ' . $name . '(' . $amount . ' USD)
                        </option>
                    ';
                }  
            }
        ?>
        </select>
        <br/>
        <button class="btn btn-info" id="pay_button">Pay by Paypal</button>
    </div>

</div>

<script type="text/javascript">
    $("#pay_button").click(function(e){
        e.preventDefault(); 
        plan_id = $('#selected_plan').val();
        c = confirm("Are you going to subscribe this plan?");
        if(c)
        {
            $.post("includes/plans/create-billing-agreement.php", { plan_id: plan_id },
                function(data) {
                    if(data)
                    {
                        window.location = data;
                    }
                    else
                    {
                        alert("Sorry, unable to delete. Please try again later!");
                    }
                }
            );
        }
    });
</script>
<?php include('includes/footer.php');?>