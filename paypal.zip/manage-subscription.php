<?php include('includes/header.php');?>
<script type="text/javascript" src="<?php echo get_app_info('path');?>/js/settings/main.js?8"></script>
<div class="row-fluid">
    <div>
        <a href="billing-agreement"><button class="btn btn-inverse">Subscribe</button></a>
        <button class="btn">Cancel Subscription</button>
    </div>
    <br/>
    <div>
	    <table class="table table-striped responsive">
            <thead>
                <tr>
                    <th><?php echo _('Payment Date');?></th>
                    <th><?php echo _('Plan Name');?></th>
                    <th><?php echo _('Amount');?></th>
                </tr>
            </thead>
            <tbody>
                
                <?php 
                   
                    $q = 'SELECT id, start_date, name, description, amount FROM payment_history';
                    $r = mysqli_query($mysqli, $q);
                    if ($r && mysqli_num_rows($r) > 0)
                    {
                        while($row = mysqli_fetch_array($r))
                        {
                            $id = $row['id'];
                            $payment_date = $row['start_date'];
                            $plan_name = $row['name'];
                            $amount = $row['amount'];
                            
                            echo '
                                <tr id="'.$id.'">
                                    <td>'. $payment_date . '</td>
                                    <td>'. $plan_name .'</td>
                                    <td>'. $amount .'</td>
                                </tr>
                                ';
                        }  
                    }
                ?>
                
            </tbody>
		</table>
    </div>
</div>
<?php include('includes/footer.php');?>
